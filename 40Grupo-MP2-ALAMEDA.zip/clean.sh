#!/bin/bash

# Grupo 40:
# Sofia Aparicio - n 81105
# Rodrigo Lousada - n 81115

rm *.final
rm virUnigramas.txt foraUnigramas.txt virBigramas.txt foraBigramas.txt virResultado.txt foraResultado.txt
